# YamurGym — how to test

YamurGym is a no-login gym planner:
- **Calendar:** week and month views.
- **Pictures:** from the wger exercise database, plus an optional cover photo for each workout.
- **Workouts:** split / multi-part workouts (for example AM + PM) and cardio blocks.
- **Calendar export:** Google Calendar and .ics.
- **Notifications:** native phone notifications that arrive even when the app is closed.

You don't need to install anything on your computer. GitHub builds the Android app for you.

---

## Part 1: Build the Android app (APK) on GitHub (about 10 minutes)

1. Sign in at https://github.com. Create a free account if you don't have one.
2. Click **+ → New repository**. Name it `yamurgym` and choose **Public**.
   - Private also works, but the free web version (Part 4) needs Public.
   - Tick **Add a README file**, then click **Create repository**.
3. Unzip `yamurgym.zip` on your computer.
4. In the repository, click **Add file → Upload files**. Drag in these items from the unzipped `yamurgym` folder:
   - `www` folder
   - `assets` folder
   - `package.json`
   - `capacitor.config.json`
   - `TESTING.md`

   Then click **Commit changes**.
5. Add the build file. Your computer may hide the `.github` folder, so create it by hand:
   - Click **Add file → Create new file**.
   - In the name box type exactly: `.github/workflows/build.yml`
   - Open `.github/workflows/build.yml` from the unzipped folder in a text editor. On Windows use Notepad; on Mac use TextEdit and turn on Format → Make Plain Text.
   - Copy everything in it and paste it into GitHub.
   - Click **Commit changes**.
6. Open the **Actions** tab. A run called **Build YamurGym** starts. Wait for the green tick (about 6–8 minutes).
   - If the run asks you to enable workflows, click **I understand… enable**. Then go to **Actions → Build YamurGym → Run workflow**.
7. Go to the repository's main page and click **Releases** on the right. Open the newest release, **YamurGym build N**, and find **YamurGym.apk**.

## Part 2: Install the app on your Android phone

1. On the phone, open the GitHub repository in Chrome. Go to **Releases** and tap **YamurGym.apk** to download it.
   - Alternatively, download it on your computer and send it to the phone by USB, Drive or WhatsApp.
2. Tap the downloaded file.
3. If Android warns about unknown apps, tap **Settings**, turn on **Allow from this source**, then go back and tap **Install**.
4. If Play Protect warns you, tap **More details → Install anyway**. This warning is normal for apps that aren't from the Play Store.
5. Open **YamurGym** from the app drawer.

## Part 3: Test checklist (inside the app)

| # | What to test | How | Expected result |
|---|---|---|---|
| 1 | Opens with sample plan | Launch the app | Calendar tab, week view. Push Day on Monday, Upper/Lower Split on Wednesday (2 parts), Cardio Burn on Friday |
| 2 | Month view | Tap **Month** | Full month grid with coloured dots on training days. Use ‹ › to change month |
| 3 | Day details | Tap any day | Workout, start time per part, and exercise pictures shown below |
| 4 | Weekly vs one-off | Pick a day → **Only this date** → choose another workout | Only that date changes and is marked "one-off" in week view. **Reset to weekly plan** undoes it |
| 5 | Exercise database | **Build** → type `squat` | Real exercises from wger with photos. If there's no internet, an offline list is used and the header shows "offline list" |
| 6 | Category filter | Tap **Chest**, **Back**, … | The list filters by muscle group |
| 7 | Split workout | **Build → Split / 2 parts** | Part A and Part B chips. Add exercises to each, rename a part, use **+ Part** for up to 4 parts |
| 8 | Cardio | **Build → Cardio** tab → **Add** Treadmill run | A cardio item with minutes, distance and intensity fields |
| 9 | Label + cover picture | Enter a label, optionally choose a cover photo, then **Save workout** | Saved in **Workouts** with the cover photo or a 4-picture collage |
| 10 | Reuse a label | **Workouts** → tap day chips (Mon…Sun) | The workout repeats weekly on those days and the calendar updates |
| 11 | Edit / duplicate / delete | Buttons on each workout card | Works. Delete asks for a second tap |
| 12 | Notifications on | **Alerts → Turn on notifications** → **Allow** | Status turns green and shows "On · N reminders set" |
| 13 | Push notification test | **Send test notification**, then lock the phone | A notification arrives within about 5 seconds |
| 14 | Real reminder while closed | Plan a workout today about 10 minutes from now, set **Remind me 5 minutes before**, then swipe the app away | The notification arrives on time with the app closed |
| 15 | Split reminders | Plan a 2-part workout with two times | One reminder for each part |
| 16 | Calendar | Day panel → **Add … to Google Calendar** | Google Calendar opens with the event pre-filled (weekly repeat if set for every week) |
| 17 | No login / persistence | Close and reopen the app | All data is still there |

**If notifications don't arrive**
- Go to phone **Settings → Apps → YamurGym → Notifications** and make sure they're **Allowed**.
- In the same app settings, go to **Alarms & reminders** and turn it **on** (Android 12+). This makes reminders arrive at the exact time.
- Samsung, Xiaomi and Huawei phones: go to **Battery → YamurGym → Unrestricted / No restrictions**. These phones otherwise stop apps from waking up.
- Open the app once a week. Each time it opens it schedules the next 8 weeks of reminders.

## Part 4: Test the web version (any phone or computer)

- **Quickest:** open `YamurGym.html` in Chrome. It is the same app in one file.
- **Online version:** the build also publishes a website. It's in **Settings → Pages** of the repository and looks like `https://YOURNAME.github.io/yamurgym/`.
  - If Pages isn't set up yet, go to **Settings → Pages → Source: GitHub Actions** and re-run the workflow.
  - On Android Chrome, use **⋮ → Add to Home screen** to install it.
- **Web limitation:** notifications only arrive while the page is open. Use the APK for real push reminders.

## Updating the app later
Edit `www/index.html` in GitHub (the pencil icon) and commit. A new APK appears under **Releases** a few minutes later. Install it over the old one; your data is kept.
